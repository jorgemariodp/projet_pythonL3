import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass

#%%
@dataclass 
class planets:
    sys:str
    G:float
    nom:str 
    mass:float 
    vitesse: np.array((2,1))
    pos: np.array((2,1))
#%%
def r(X1,Y1):
    X2,Y2=0,0
    r= np.sqrt((X1-X2)**2 + (Y1-Y2)**2)
    return r

#%%

#Calcul de coordonnes par la methode des Differences Finies
def diffin(x0,vx0,y0,vy0,h,t,G,M_soleil):

    UD= np.zeros((2,t))
    
    
    UD[0,0]= x0
    UD[0,1]= x0 + vx0*h
    
    UD[1,0]= y0
    UD[1,1]= y0 + vy0*h

    for i in range (1,t-1,1):
        
        R= r(UD[0,i],UD[1,i])
        UD[:,i+1]= 2*UD[:,i] - UD[:,i-1] + (h**2)*(-G*M_soleil/R**3)*(UD[:,i])
        
    return UD

#%%
#Fonction qui prend les informations correpondante a chaque planet
#System auquel elle appartient,constante gravitationelle,nom,mass,vecteur vitesse[X,Y],position[X,Y]

def get(sysso,h,qant):

    with open("DATA/"+sysso,"r") as file:
        res_p=file.read()
    trash_p= res_p.split("\n")
    system=[]
    for i in range(0,len(trash_p)):
        with open(trash_p[i],"rb") as file:
            sys_name=np.load(file)
            G=np.load(file)
            nom=np.load(file)
            mass=np.load(file)
            vitesse=np.load(file)
            pos=np.load(file)
        system.append(planets(sys_name,G, nom, mass, vitesse, pos))            #creation de la lsite de dataclasses de planets

    return system

#%%

qant=1445400                                                                   #Qantite simulation pour un tour de Neptune au tour du soleil
h=3600                                                                         #Pas de simulation en secondes, soit une heure
sysso="System Solaire.txt"
system=get(sysso, h, qant)

pos=[]
for i in range (1,len(system),1):
    pos.append(diffin(system[i].pos[0],system[i].vitesse[0],system[i].pos[1],system[i].vitesse[1],h,qant,system[0].G,system[0].mass))




plt.figure()

plt.plot(pos[0][0,:],pos[0][1,:],c='gray',label ='Mercure')
plt.plot(pos[1][0,:],pos[1][1,:],label ='Venus')
plt.plot(pos[2][0,:],pos[2][1,:],c='green',label ='Terre')
plt.plot(pos[3][0,:],pos[3][1,:],label ='Mars')
plt.plot(pos[4][0,:],pos[4][1,:],c='violet',label ='Jupiter')
plt.plot(pos[5][0,:],pos[5][1,:],c='black',label ='Saturne')
plt.plot(pos[6][0,:],pos[6][1,:],'g--',label ='Uranus')
plt.plot(pos[7][0,:],pos[7][1,:],c='blue',label ='Neptune')
plt.legend()

plt.title("Simulation du systeme solaire simplifié",fontsize = 40)

plt.plot(0,0,'o',c='r',label='soleil') # la soleil
plt.xlabel("position en x")
plt.ylabel("position en y")
plt.axis("equal")
plt.show()