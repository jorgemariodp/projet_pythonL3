# -*- coding: utf-8 -*-
"""
Created on Tue Jan 10 18:10:15 2023

@author: Jorge Mario
"""

import numpy as np
import matplotlib.pyplot as plt


def r(X1,X2,Y1,Y2):                                             #Calcul de la distance de la lune a la terre
    r= np.sqrt((X1-X2)**2 + (Y1-Y2)**2)
    return r

#Fonction qui prends en parametre une liste de taille=2 et renvoi la donnee de la case N=2
def split(l):
    data=l.split("=")
    data[1]=float(data[1])
    return data[1]

#Fonction qui va cherher les information de la lune et la terre, clean renvoi une liste avec tous les donnees separees par un retour a la ligne
def clean(txt):
    with open("data/"+ txt,"r") as file:
        trash=file.read()
    data= trash.split("\n")
    info=[]
    for i in range(0,len(data)):
        info.append(split(data[i]))
    return info

#Fichiers .txt ou se trouves les donnees (Vitesse,Position,Masse,Constant de Gravitation) de la lune et la terre
terre="terre.txt"
lune="lune.txt"

#Liste contenant les donnees specifiques a la terre et la lune separement
#info[0]=vitesse(X);info[1]=vitesse(Y);info[3]=masse(Kg);info[4]=Position[X];info[5]=Position[Y];info[6]=Constante de gravitation universelle
info_t=clean(terre)
info_l=clean(lune)



G= info_t[5]                                                    #Constante de gravitation universelle km^3.kg^-1.s^-2
#Creation des constantes pour la lune et la terre
K_lune= -G*info_t[2]
K_terre= -G*info_l[2]

qant=120000                                                     #Qantite de simulation pour 2 mois environ
h=40                                                            #Pas de simulation (secondes)

#Creation des vecteurs pour la lune et le tarre U[0,k] coordonnees suivant X, U[1,K] suivant Y
U_L= np.zeros((2,qant))
U_T= np.zeros((2,qant))

#Initialisation de la terre et la lune

U_L[0,0]= info_l[3]                                             # Distance entre la lune et la terre suivant X
U_L[0,1]= info_l[3] + info_l[0]*h                               #Vitesse de la lune en Km/s suivant X
U_L[1,0]= info_l[4]                                             #Distance entre la lune et la terre suivant Y
U_L[1,1]= info_l[4] + info_l[1]*h                               #Vitesse de la lune en Km/s suivant Y



for i in range (1,qant-1,1):
    
    R= r(U_L[0,i],U_T[0,i],U_L[1,i],U_T[1,i])
    
    U_L[:,i+1]= 2*U_L[:,i]- U_L[:,i-1] + (h**2)*(K_lune/R**3)*(U_L[:,i]-U_T[:,i])
    U_T[:,i+1]= 2*U_T[:,i]- U_T[:,i-1] + (h**2)*(K_terre/R**3)*(U_T[:,i]-U_L[:,i])

plt.figure()
plt.plot(U_L[0,:],U_L[1,:],label='Lune')
plt.plot(U_T[0,:],U_T[1,:],label='Terre')
plt.legend()
plt.xlabel("x(km)")
plt.ylabel("y(km)")
plt.title("Systeme Terre - Lune")
plt.axis("equal")
plt.show()