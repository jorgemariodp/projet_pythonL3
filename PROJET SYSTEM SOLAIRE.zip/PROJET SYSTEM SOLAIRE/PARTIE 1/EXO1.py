import numpy as np
from matplotlib import pyplot as plt

def r(X,Y):                     #CALCUL DE LA DISTANCE DE LA LUNE A LA TERRE
    r= np.sqrt((X)**2 + (Y)**2)
    return r

#Fonction qui prends en parametre une liste de taille=2 et renvoi la donnee de la case N=2
def split(l):
    data=l.split("=")
    data[1]=float(data[1])
    return data[1]

#Fonction qui va cherher les information de la lune et la terre, clean renvoi une liste avec tous les donnees separees par un retour a la ligne
def clean(txt):
    with open("data/"+ txt,"r") as file:
        trash=file.read()
    data= trash.split("\n")
    info=[]
    for i in range(0,len(data)):
        info.append(split(data[i]))
    return info


#%%
def euler(x_lune,vx_lune,y_lune,vy_lune,h,t,G,M_terre):
    UE=np.zeros((4,t))
    
    UE[0,0]=x_lune
    UE[1,0]=vx_lune
    UE[2,0]=y_lune
    UE[3,0]=vy_lune
    
    
    for i in range (1,t,1):
        R=r(UE[0,i-1],UE[2,i-1])
        K=-G*M_terre/R**3
        
        UE[0:3:2,i]= UE[0:3:2,i-1] + h*UE[1:4:2,i-1]
        UE[1:4:2,i]= UE[1:4:2,i-1] + h*K *UE[0:3:2,i-1]
    return UE



#%%
# methode de runge kutta 2

def k(U,h,K,i):                                                                 #CALCUL DE K1 ET K2
    K1=np.zeros((4,1))
    K2=np.zeros((4,1))

    K1[0:3:2,0]= U[1:4:2,i-1]*(h/2) 
    K1[1:4:2,0]= U[0:3:2,i-1]*K*(h/2)

    K2[0:3:2,0]= (U[1:4:2,i-1]+h*K*U[0:3:2,i-1])*(h/2)
    K2[1:4:2,0]= K*U[0:3:2,i-1]*(h/2) + (h*K*U[1:4:2,i-1])*((h/2))

    return K1,K2

def RungeKutta(x_lune,vx_lune,y_lune,vy_lune,h,t,G,M_terre):

    UR= np.zeros((4,t))
    
    UR[0,0]= x_lune
    UR[1,0]= vx_lune
    UR[3,0]= y_lune
    UR[3,0]= vy_lune
    
    
    for i in range(1,t,1):
        
        R= r(UR[0,i-1],UR[2,i-1])
        K= -G*M_terre/R**3
        K1,K2= k(UR,h,K,i)
        UR[0:3:2,i]= UR[0:3:2,i-1] + K1[0:3:2,0] + K2[0:3:2,0]
        UR[1:4:2,i]= UR[1:4:2,i-1] + K1[1:4:2,0] + K2[1:4:2,0]
    return UR



#%%
# methode des differences finis 

def diffin(x_lune,vx_lune,y_lune,vy_lune,h,t,G,M_terre):

    UD= np.zeros((2,t))
    
    
    UD[0,0]= x_lune
    UD[0,1]= x_lune + vx_lune*h
    
    UD[1,0]= y_lune
    UD[1,1]= y_lune + vy_lune*h

    for i in range (1,t-1,1):
        
        R= r(UD[0,i],UD[1,i])
        UD[:,i+1]= 2*UD[:,i] - UD[:,i-1] + (h**2)*(-G*M_terre/R**3)*(UD[:,i])
        
    return UD

#%%

#Fichiers .txt ou se trouves les donnees (Vitesse,Position,Masse,Constant de Gravitation) de la lune et la terre
terre="terre.txt"
lune="lune.txt"

#Liste contenant les donnees specifiques a la terre et la lune separement
#info[0]=vitesse(X);info[1]=vitesse(Y);info[3]=masse(Kg);info[4]=Position[X];info[5]=Position[Y];info[6]=Constante de gravitation universelle
info_l=clean(lune)

vy_lune= 1.020 #Km/s
vx_lune=0

x_lune=384400
y_lune=0

G= 6.6742*(10**(-20)) 
M_terre=5.972*(10**24) 

h=3600
t=1500

UE=euler(x_lune,vx_lune,y_lune,vy_lune,h,t,G,M_terre)
UR=RungeKutta(x_lune,vx_lune,y_lune,vy_lune,h,t,G,M_terre)
UD=diffin(x_lune,vx_lune,y_lune,vy_lune,h,t,G,M_terre)


plt.figure()
plt.title('Simulation terre lune avec les methodes de calcul')
plt.plot(UD[0,0:],UD[1,0:],label='Difference finies')
plt.plot(UR[0,:], UR[2,:],label='ruge kutta 2')
plt.plot(UE[0,:],UE[2,:],label='methode d\'euler')
plt.plot(0,0,'o',c='g',label='terre') #terre
plt.xlabel('position x')
plt.ylabel('position y')
plt.legend(loc = 'upper right')
plt.axis("equal")
plt.show()