# -*- coding: utf-8 -*-
"""
Created on Sat Dec 17 12:01:59 2022

@author: Jorge Mario
"""
import matplotlib.pyplot as plt
import random
def plott(co,system,qant):

    
    plt.figure()
    plt.plot(0, 0,marker="o",markersize=10,label=system[0].nom)
    
    for i in range(1,len(system)):
            col=["#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)])]
            plt.plot(co[i][0,:], co[i][1,:],marker="o",markersize=1,color=col[0],label=system[i].nom)

    plt.axis("equal")
    plt.title(system[0].sys)
    plt.legend()
    plt.show() 

