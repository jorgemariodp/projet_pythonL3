# -*- coding: utf-8 -*-
"""
Created on Wed Dec 14 14:49:19 2022

@author: Jorge Mario
"""
import numpy as np
from dataclasses import dataclass
import os


#%%
@dataclass 
class planets:
    sys:str
    G:float
    nom:str 
    mass:float 
    vitesse: np.array((2,1))
    pos: np.array((2,1))


#%%
#calcul de la ditance entre planets
def r(X1,X2,Y1,Y2):
    r= np.sqrt((X1-X2)**2 + (Y1-Y2)**2)
    return r**3

#%%
#initialisation des positions x et y grace aux conditions initiales rensignes ou deja etablies
def init(u,pos,v,h,i,system):
    u[0,0]= pos[0]
    u[0,1]= pos[0] + v[0]*h
    u[1,0]= pos[1]
    u[1,1]= pos[1] + v[1]*h
    system[i].pos=u[:,1]

    return u

#%%
#cacul de la position grace a laccelreation
def accel(system,h):                                                           #dataclass avec les planet en parametre + pas de temps

    ZX=np.zeros((len(system),len(system)))
    ZY=np.zeros((len(system),len(system)))

    for i in range (0,len(system)):
        for j in range (0,len(system)):

            R=r(system[i].pos[0],system[j].pos[0],system[i].pos[1],system[j].pos[1])
            ZX[i,j]= (h**2)*((-(system[i].G)*system[j].mass)/R)*(system[i].pos[0]-system[j].pos[0])
            ZY[i,j]= (h**2)*((-(system[i].G)*system[j].mass)/R)*(system[i].pos[1]-system[j].pos[1])

    a=np.zeros((2,len(system)))
    for i in range(0,len(system)):                                             #boucle de somme des differentess interactions 
        a[0,i]=np.nansum(ZX[i,:])
        a[1,i]=np.nansum(ZY[i,:])

    return a

#%%
#partie centrale du programme qui prendre la liste de dataclass contenant les informations des planets
def simu(system,qant,h):

    planet=[]
    for i in range(0,len(system)):
        planet.append(np.zeros((2,qant)))
        planet[i]=init(planet[i], system[i].pos,system[i].vitesse, h,i,system)
    
    for i in range(1,qant-1,1):
        a=accel(system,h)
        for j in range(1,len(system)):
            planet[j][:,i+1]= 2*planet[j][:,i] - planet[j][:,i-1] + a[:,j]
            system[j].pos=planet[j][:,i+1]

    return planet

#%%
#selction des anciens systems 
def old(selec_2,tems):

    with open("sys/"+tems[selec_2]+"/"+tems[selec_2]+".txt","r") as file:
        res_p=file.read()
    trash_p= res_p.split("\n")
    system_2=[]
    for i in range(0,len(trash_p)):
        with open(trash_p[i],"rb") as file:
            sys_name=np.load(file)
            G=np.load(file)
            nom=np.load(file)
            mass=np.load(file)
            vitesse=np.load(file)
            pos=np.load(file)
        system_2.append(planets(sys_name,G, nom, mass, vitesse, pos))          #creation de la lsite de dataclasses de planets
    h,qant=int(input("Choissez votre pas de temps en heures: \n")),int(input("Choissez le temps de simulation en jours: \n"))
    hc=h
    h=h*3600
    qant=(qant*24)//hc

    co=simu(system_2,qant,h)

    return co,system_2,qant

#%%
#creation dun nouveau systeme solaire
def create(res):

    sys= "SYSTEMS.txt"
    with open(sys,"r") as file:
        res=file.read()
    tems=res.split("\n")

    system_name=str(input("Nom de votre systeme solaire: "))
    for i in range(0,len(tems)):
        if system_name==tems[i]:
            print("Ce systeme existe deja\nVeuillez choisir un nouveau")
            NN=str(input("Nom de votre systeme solaire: "))
            if system_name==NN:
                print("ERROR")
                os._exit(0)
            else:
                system_name=NN
            break

    os.makedirs("sys/"+system_name, exist_ok=True)
    with open(sys,"w") as file:
        for i in range(0,len(tems)):
            file.write(tems[i]+"\n")
        file.write(system_name)
    system=[]
    G= float(input("Entrez la constante de gravitation du systeme : "))
    ask=int(input("Combien de planets + etoile a votre system solaire {}: ".format(system_name)))
    nom=[]
    for i in range(0,ask):

        if i ==0:
            nom.append(str(input("Entrez le nom de l'etoile: ")))
            with open("sys/"+system_name+"/"+system_name+".txt","w") as file:
                file.write("sys/"+system_name+"/"+nom[i]+".npy")
        else:
            nom.append(str(input("Entrez le nom de la planet ({}): ".format(i))))

            with open("sys/"+system_name+"/"+system_name+".txt","r") as file:
                res_2=file.read()
            trash=res_2.split("\n")
            with open("sys/"+system_name+"/"+system_name+".txt","w") as file:
                for j in range(0,len(trash)):
                    file.write(trash[j]+"\n")
                file.write("sys/"+system_name+"/"+nom[i]+".npy")

        if i==0:
            mass=float(input("Masse de l'etoile {} : ".format(nom[i])))
            vx=0
            vy=0
            vitesse=np.array([vx,vy])
            px=0
            py=0
            pos=np.array([px,py])
        else:
            mass=float(input("Masse de la plante {} : ".format(nom[i])))
            vx=float(input("Entrez la vitesee en X: "))
            vy=float(input("Entrez la vitesee en Y: "))
            vitesse=np.array([vx,vy])
            px=float(input("Entrez la position en X: "))
            py=float(input("Entrez la position en Y: "))
            pos=np.array([px,py])
        
        system.append(planets(system_name,G, nom[i], mass, vitesse, pos))

        with open("sys/"+system_name+"/"+nom[i]+".npy","wb") as file:
            np.save(file,system_name)
            np.save(file, G)
            np.save(file,nom[i])
            np.save(file, mass)
            np.save(file,vitesse)
            np.save(file, pos)

    return system

#%%