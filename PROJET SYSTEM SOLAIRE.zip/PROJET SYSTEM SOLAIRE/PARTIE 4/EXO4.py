# -*- coding: utf-8 -*-
"""
Created on Thu Dec 15 09:33:16 2022

@author: Jorge Mario
"""
from CALCUL import old,create,simu
from plot import plott
import matplotlib.pyplot as plt
from matplotlib import animation


print("Bienvenu au simulataur de systemes solaires\n""Veuillez choisir une option parmis les uisvantes:\n" \
"(1)CREER MON PROPRE SYSTEME\n(2)UTILISER UN SYSTEME EXISTANT")


sys= "SYSTEMS.txt"                                                             #Fichier avec les noms de systems enregistres
with open(sys,"r") as file:
    res=file.read()
tems=res.split("\n")
    
selec=int(input("Selectionnez votre option:"))
selec_2=99
if selec==2:                                                                   #Option systems deja crees
    print("Systems enregistres:\n")
    for i in range(0,len(tems)):
        print("  ({}) {} ".format(i,tems[i]))
    selec_2= int(input("Choissisez les syteme a simuler: "))
    co,system,qant=old(selec_2,tems)
if selec==1:                                                                   #Option creation dun nouveau system
    system=create(selec)
    print("\n Votre systeme a ete bien enregistre \n")
    h,qant=float(input("Choissez votre pas de temps en heures: ")),int(input("Choissez le temps de simulation en jours: "))
    h,qant=h*3600,qant*24
    co=simu(system,qant,h)

print("\nVoulez vous simuler le systeme solaire en animation\n")
print("Oui(1)\nNon(0)\n")
sim=int(input("Choix: "))

#Choix du type de simulation(plot ou animation)
if selec_2!=0 or sim==0:
    (plott(co, system, qant))

#%%
if sim==1 and selec_2==0:

#Animation disponible du system solaire
    fig, ax = plt.subplots(figsize=(10,10))
    ax.set_aspect('equal')
    ax.grid()
    xslist,yslist=[],[]
    xelist,yelist=[],[]
    xmlist,ymlist=[],[]
    xmslist,ymslist=[],[]
    xulist,yulist=[],[]
    xnlist,ynlist=[],[]
    xsalist,ysalist=[],[]
    xjlist,yjlist=[],[]
    xvlist,yvlist=[],[]
    
    for j in range(0,qant,1):
        xslist.append(co[0][0,j])
        yslist.append(co[0][1,j])
        
        xmlist.append(co[1][0,j])
        ymlist.append(co[1][1,j])
        
        xvlist.append(co[2][0,j])
        yvlist.append(co[2][1,j])
        
        xelist.append(co[3][0,j])
        yelist.append(co[3][1,j])
        
        xmslist.append(co[4][0,j])
        ymslist.append(co[4][1,j])
        
        xjlist.append(co[5][0,j])
        yjlist.append(co[5][1,j])
        
        xsalist.append(co[6][0,j])
        ysalist.append(co[6][1,j])
        
        xulist.append(co[7][0,j])
        yulist.append(co[7][1,j])
        
        xnlist.append(co[8][0,j])
        ynlist.append(co[8][1,j])
    
    
    RMAX= co[8][0,0]

    point_0,    = ax.plot([co[0][0,0]], [0], marker="o", markersize=4, markeredgecolor="yellow", markerfacecolor="yellow")
    
    line_1,     = ax.plot([],[],'black',lw=0.1)
    point_1,    = ax.plot([co[1][0,0]], [0], marker="o", markersize=4, markeredgecolor="#9FAFB4", markerfacecolor="#9FAFB4")

    line_2,     = ax.plot([],[],'black',lw=0.1)
    point_2,    = ax.plot([co[2][0,0]], [0], marker="o", markersize=5, markeredgecolor="#E69E72", markerfacecolor="#E69E72")

    line_3,     = ax.plot([],[],'black',lw=0.1)
    point_3,    = ax.plot([co[3][0,0]], [0], marker="o", markersize=6, markeredgecolor="#3F962C", markerfacecolor="#3F962C")
    text_3      = ax.text(co[3][0,0],0,system[3].nom)

    line_4,     = ax.plot([],[],'black',lw=0.1)
    point_4,    = ax.plot([co[4][0,0]], [0], marker="o", markersize=4, markeredgecolor="#FB3205", markerfacecolor="#FB3205")

    line_5,     = ax.plot([],[],'black',lw=0.1)
    point_5,    = ax.plot([co[5][0,0]], [0], marker="o", markersize=19, markeredgecolor="#EF9A3B", markerfacecolor="#EF9A3B")

    line_6,     = ax.plot([],[],'black',lw=0.1)
    point_6,    = ax.plot([co[6][0,0]], [0], marker="o", markersize=17, markeredgecolor="#DBB312", markerfacecolor="#DBB312")

    line_7,     = ax.plot([],[],'black',lw=0.1)
    point_7,    = ax.plot([co[7][0,0]], [0], marker="o", markersize=7, markeredgecolor="#12C6DB", markerfacecolor="#12C6DB")

    line_8,     = ax.plot([],[],'black',lw=0.1)
    point_8,    = ax.plot([co[8][0,0]], [0], marker="o", markersize=4, markeredgecolor="#1261DB", markerfacecolor="#1261DB")

    sx_data,mx_data,vx_data,tx_data,msx_data,jx_data,sax_data,ux_data,nx_data= [],[],[],[],[],[],[],[],[]
    sy_data,my_data,vy_data,ty_data,msy_data,jy_data,say_data,uy_data,ny_data= [],[],[],[],[],[],[],[],[]

    def update(i):
        
        sx_data.append(xslist[i])
        sy_data.append(yslist[i])
        
        mx_data.append(xmlist[i])
        my_data.append(xmlist[i])
        
        vx_data.append(xvlist[i])
        vy_data.append(yvlist[i])
        
        tx_data.append(xelist[i])
        ty_data.append(yelist[i])
        
        msx_data.append(xmslist[i])
        msy_data.append(ymslist[i])
        
        jx_data.append(xjlist[i])
        jy_data.append(yjlist[i])
        
        sax_data.append(xsalist[i])
        say_data.append(ysalist[i])
        
        ux_data.append(xulist[i])
        uy_data.append(yulist[i])
        
        nx_data.append(xnlist[i])
        ny_data.append(ynlist[i])


        point_0.set_data(xslist[i],yslist[i])

        line_1.set_data(mx_data,my_data)
        point_1.set_data(xmlist[i],ymlist[i])

        line_2.set_data(vx_data,vy_data)
        point_2.set_data(xvlist[i],yvlist[i])

        line_3.set_data(tx_data,ty_data)
        point_3.set_data(xelist[i],yelist[i])
        text_3.set_position((xelist[i],yelist[i]))

        line_4.set_data(msx_data,msy_data)
        point_4.set_data(xmslist[i],ymslist[i])

        line_5.set_data(jx_data,jy_data)
        point_5.set_data(xjlist[i],yjlist[i])

        line_6.set_data(sax_data,say_data)
        point_6.set_data(xsalist[i],ysalist[i])

        line_7.set_data(ux_data,uy_data)
        point_7.set_data(xulist[i],yulist[i])

        line_8.set_data(nx_data,ny_data)
        point_8.set_data(xnlist[i],ynlist[i])

        ax.axis('equal')
        ax.set_xlim(-RMAX,RMAX)
        ax.set_ylim(-RMAX,RMAX)
    
        return point_0,point_1,line_1,point_2,line_2,point_3,line_3,text_3,point_4,line_4,point_5,line_5,point_6,line_6,point_7,line_7,point_8,line_8
    
    anim = animation.FuncAnimation(fig,func=update,frames=len(xelist),interval=0.1,blit=True)
    plt.title("System Solaire")
    plt.xlabel("Position en x")
    plt.ylabel("Position en y")
    plt.axis('equal')
    plt.show()    
#%%
#Fin du programme